/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nhendric <nhendric@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/29 08:09:27 by nhendric          #+#    #+#             */
/*   Updated: 2020/02/05 19:47:13 by nhendric         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf.h"

int			raycast(t_data *in) 
{	
	double i;
	
	if (!(in->hero->ray_dir = (t_dxy *)malloc(sizeof(t_dxy))))
		return (-1);	
	i = 0;
	while (i < WIN_W) {
		in->hero->ray_dir->x = (in->hero->dir->x + (in->hero->cam->x * 
			((2 * (i / (double)WIN_W)) - 1)));		
		in->hero->ray_dir->y = (in->hero->dir->y + (in->hero->cam->y * 
			((2 * (i / (double)WIN_W)) - 1)));
		i++;
	}
	return (0);
}


int			main_loop(t_data *in) 
{	
	int done = 1;
	(void)in;
	
	printf(" Main game loop");
	while (!done){
		
	}
	
	return (0);
}

int			init(t_data *in) 
{
	printf(" init started. ");

	if (!(in->hero = (t_hero *)malloc(sizeof(t_hero))) || 
		!(in->hero->pos = (t_dxy *)malloc(sizeof(t_dxy))) ||
		!(in->hero->dir = (t_dxy *)malloc(sizeof(t_dxy))) ||

		!(in->hero->sideDist = (t_dxy *)malloc(sizeof(t_dxy))) || 
		!(in->hero->deltaDist = (t_dxy *)malloc(sizeof(t_dxy))) || 
		!(in->hero->plane = (t_dxy *)malloc(sizeof(t_dxy))) || 
		!(in->hero->step = (t_ixy *)malloc(sizeof(t_ixy))) || 
		!(in->hero->cam = (t_dxy *)malloc(sizeof(t_dxy))))
		return (-1);

	pos_init(in);
	in->hero->cam->x = 0;
	in->hero->cam->y = 0.66;
	in->hero->dir->x = -1;
	in->hero->dir->y = 0;
	in->hero->plane->x = 0;
	in->hero->plane->y = 0.66;
	in->hero->moveSpeed = 0.4;
	in->hero->rotSpeed= 0.2;

	in->win = mlx_new_window(in->mlx, WIN_W, WIN_H, in->map_name);
	in->img = mlx_new_image(in->mlx, WIN_W, WIN_H);
	in->img_data =  (int *)mlx_get_data_addr(in->img_data, &in->bpp, &in->size_l, &in->endian);
	
	printf("raycast");
	printf(" init started. ");

	return (0);
	// raycast(in);
}

int			pos_init(t_data *in) 
{
	int i;
	int j;

	i = 0;
	while (i < in->map_h) {
		j = 0;
		while (j < in->map_w) {
			if (in->in_proc->atoi_int[i][j] == 0) {
				in->hero->pos->x = i;
				in->hero->pos->y = j;
				return (0);
			}
			j++;
		}
		i++;
	}
	printf(" \n Unable to find valid start position, goodbye. \n");
	exit(1);
}

int			map_print(t_data *in)
{
	int		i;
	int		j;
	
	printf(" \n included map: \n");
	i = 0;
	while (i < in->map_h)
	{
		j = 0;
		while (j < in->map_w)
		{
			printf(" %d ", in->in_proc->atoi_int[i][j]);
			j++;
		}
		printf("\n");
		i++;
	}

	return (0);
}

// fucked, need to validate borders exist
int			map_validate(t_data *in)
{
	int		i;
	int		j;
	
	i = 0;
	while (i < in->map_h && in->in_proc->atoi_int[i][0] == 1 && in->in_proc->atoi_int[i][in->map_w - 1] == 1)
	{
		j = 0;
		
		while (j < in->map_w && in->in_proc->atoi_int[0][j] == 1 && 
		in->in_proc->atoi_int[in->map_h - 1][j] == 1 && 
		in->in_proc->atoi_int[i][j] >= 0 && 
		in->in_proc->atoi_int[i][j] <= 4) 
		{
			printf("entered");
			if(in->in_proc->atoi_int[i][j] != 1) {
				printf("isdfrgd ");
				break;
			}
				
			if ((i == (in->map_h -1)) && (j == (in->map_w -1))) {	
				printf("i: %d j: %d value: %d ", i, j, in->in_proc->atoi_int[i][j]);
				return (0);
			}
			j++;
		}
		i++;
	}
	printf(" \n invalid map: \n invalid value at col: %d row: %d ", ++j, ++i);
	return (-1);
}

int			i_store(t_data *in)
{
	printf(" i_store started. ");

	int		i;
	int		j;
	
	i = 0;
	if (!(in->in_proc->atoi_int = (int **)malloc(sizeof(int *) * in->map_h)))
		return (-1);
	while (i < in->map_h)
	{
		in->in_proc->atoi_int[i] = (int *)malloc(sizeof(int) * in->map_w);
		j = 0;
		while (j < in->map_w)
		{
			in->in_proc->atoi_int[i][j] = ft_atoi(in->in_proc->spl_str[i][j]);
			free(in->in_proc->spl_str[i][j]);
			j++;
		}
		free(in->in_proc->spl_str[i]);
		i++;
	}
	// map_validate(in);
	printf("i_store done. ");

	init(in);
	return (0);
}

int			line_w(t_data *in)
{
	printf(" line_w started. ");

	int		i;
	int		j;
	int		cnt;

	j = 0;
	cnt = 0;
	if (!(in->in_proc->spl_str = (char ***)malloc(sizeof(char **) *
					in->map_h + 1)))
		return (-1);
	i = 0;
	printf(" map_h %d \n", in->map_h);
	
	while (i < in->map_h)
	{
		printf(" ddddd  i %d ", i);
		in->in_proc->spl_str[i] = ft_strsplit(in->in_proc->in_str[i], ' ');
		printf(" %s \n", in->in_proc->in_str[i]);
		// free(in->in_proc->in_str[i]);
		i++;
	}
	printf(" jhgjlhgg ");

	// free(in->in_proc->in_str);
	i = 0;
	while (in->in_proc->spl_str[i][j++])
		cnt++;
	in->map_w = cnt;

	printf(" line_w done. ");

	i_store(in);
	return (0);
}

void			map_read(t_data *in)
{
	printf("Map read started. ");

	int		i;
	int		fd;
	char	*line;

	i = 0;
	if((fd = open(in->map_name, O_RDONLY)) == -1) {	
		printf("Map: %s does not exist. ", in->map_name);
		exit(1);
	}	
	while (get_next_line(fd, &line) > 0) {
		i++;
	}
	close(fd);
	in->map_h = i;
	if (!(in->in_proc = (t_proc *)malloc(sizeof(t_proc))))
		return;
	if (!(in->in_proc->in_str = (char **)malloc(sizeof(char *) * i + 1)))
		return;
	fd = open(in->map_name, O_RDONLY);
	i = 0;
	while (get_next_line(fd, &line) > 0)
		in->in_proc->in_str[i++] = line;
	close(fd);
	free(line);
	printf("Map read done. ");
	line_w(in);

}

int			press(int key)
{
	if (key == 53)
		exit(1);
	return (0);
}

/*
int			free_sh(t_data in)
{
	free(in->map_name);
	free(in->in_proc);

	return (0);
}
*/

void	finish(t_data *in){
	mlx_destroy_window(in->mlx, in->win);
	exit(1);
}

int			main(int argc, char **argv)
{	
	t_data		*in;
	
	if (argc != 2)
		return (-1);
	if (!(in = (t_data *)malloc(sizeof(t_data))))
		return (-1);
	if(!(in->mlx = (void *)malloc(sizeof(void *))))
		return(-1);	
	if(!(in->mlx = mlx_init()))
		return(-1);
	in->map_name = ft_strdup(argv[1]);

	if (!(in->win = mlx_new_window(in->mlx, WIN_W, WIN_H, in->map_name)))
		return (-1);

	map_read(in);
	/*
	if (init(in) == -1)
		finish(in);
	*/
	// mlx_key_hook(in->win, press, 0);
	// while (in->mlx != NULL)
		// mlx_loop(in->mlx);

	printf(" What up bitches ");
	
	return (0);
}